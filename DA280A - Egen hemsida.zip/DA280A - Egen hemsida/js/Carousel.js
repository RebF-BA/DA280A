document.addEventListener("DOMContentLoaded", function () {
    const carousel = document.querySelector(".carousel-container");
    const images = document.querySelectorAll(".carousel-container figure");
    const totalImages = images.length;
    let index = 0;

    const updateCarousel = () => {
        const offset = -index * 100;
        carousel.style.transform = `translateX(${offset}%)`;
    };

    document.getElementById("next-btn").addEventListener("click", () => {
        index = (index + 1) % totalImages;
        updateCarousel();
    });

    document.getElementById("prev-btn").addEventListener("click", () => {
        index = (index - 1 + totalImages) % totalImages;
        updateCarousel();
    });

    setInterval(() => {
        index = (index + 1) % totalImages;
        updateCarousel();
    }, 5000);
});

document.addEventListener("DOMContentLoaded", function () {
    const figures = document.querySelectorAll(".carousel-container figure");

    figures.forEach(figure => {
        const img = figure.querySelector("img");
        figure.style.setProperty("--bg-image", `url(${img.src})`);
    });
});
