const faqClick = document.getElementById('FAQ-click');
const faqSection = document.getElementById('FAQ-section');
const faqArrow = faqClick.querySelector('span');

faqClick.addEventListener('click', () => {
    if (faqSection.style.display === 'none' || faqSection.style.display === '') {
        faqSection.style.display = 'block';
        faqArrow.innerHTML = '&#9650;';
    } else {
        faqSection.style.display = 'none';
        faqArrow.innerHTML = '&#9660;';
    }
});
