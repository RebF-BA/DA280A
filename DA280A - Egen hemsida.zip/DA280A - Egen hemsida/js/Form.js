document.getElementById("contactForm").addEventListener("input", function (e) {
    const email = document.getElementById("email");
    const phone = document.getElementById("phone");

    if (email.validity.typeMismatch) {
        email.setCustomValidity("Ange en giltig e-postadress.");
    } else {
        email.setCustomValidity("");
    }

    if (!phone.value.match(/^\+?[0-9]{10,}$/)) {
        phone.setCustomValidity("Ange ett giltigt telefonnummer.");
    } else {
        phone.setCustomValidity("");
    }
});


document.getElementById("contactForm").addEventListener("submit", function (e) {
    e.preventDefault();

    localStorage.setItem("formData", JSON.stringify({
        firstname: document.getElementById("fname").value,
        lastname: document.getElementById("lname").value,
        email: document.getElementById("email").value,
        phone: document.getElementById("phone").value,
        reason: document.getElementById("reason").value,
        message: document.getElementById("message").value
    }));

    alert("Tack för ditt meddelande! Vi har sparat din information.");
    this.reset();

});

window.onload = function () {
    const savedData = JSON.parse(localStorage.getItem("formData"));
    if (savedData) {
        document.getElementById("fname").value = savedData.firstname || "";
        document.getElementById("lname").value = savedData.lastname || "";
        document.getElementById("email").value = savedData.email || "";
        document.getElementById("phone").value = savedData.phone || "";
        document.getElementById("reason").value = savedData.reason || "";
        document.getElementById("message").value = savedData.message || "";
    }
};




