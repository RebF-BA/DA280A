
alert("Välkomment till min hemsida!");

const userConfirmed = confirm("Vill du fortsätta?");
if (userConfirmed) {
    const userName = prompt("Vad heter du??");
    alert(`Hej, ${userName || "John doe"}!`);
} else {
    alert("Hejdå!");
}


const timeout = setTimeout(() => {
    console.log("This message appears after 3 seconds");
}, 3000);


let count = 0;
const interval = setInterval(() => {
    console.log(`Interval count: ${++count}`);
    if (count === 5) {
        clearInterval(interval);
        console.log("Interval cleared!");
    }
}, 1000); 