const video = document.getElementById("video");
const toggleButton = document.getElementById("toggle_button");

toggleButton.addEventListener("click", () => {
    if (video.paused) {
        video.play();
        toggleButton.textContent = "Pausa";
    } else {
        video.pause();
        toggleButton.textContent = "Spela";
    }
});

const logContainer = document.createElement("div");
document.body.appendChild(logContainer);

toggleButton.addEventListener("click", () => {
    const log = document.createElement("p");
    log.textContent = video.paused ? "Video är paused." : "Video spelar.";
    logContainer.appendChild(log);

    setTimeout(() => {
        log.remove();
    }, 5000);
});

toggleButton.addEventListener("mouseover", () => {
    toggleButton.classList.add("hovered");
    console.log("Mouse over button");
});

toggleButton.addEventListener("mouseout", () => {
    toggleButton.classList.remove("hovered");
    console.log("Mouse out of button");
});

document.body.addEventListener("mousemove", (event) => {
    console.log(`Mouse coordinates: X=${event.pageX}, Y=${event.pageY}`);
});

toggleButton.addEventListener("click", (event) => {
    event.preventDefault();
    console.log("Default behavior prevented.");
});

logContainer.style.position = "fixed";
logContainer.style.bottom = "10px";
logContainer.style.left = "10px";
logContainer.style.backgroundColor = "rgba(0, 0, 0, 0.7)";
logContainer.style.color = "white";
logContainer.style.padding = "10px";
logContainer.style.borderRadius = "5px";
logContainer.style.maxWidth = "300px";
