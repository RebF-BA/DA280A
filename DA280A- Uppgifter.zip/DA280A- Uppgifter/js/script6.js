const audioElement = document.getElementById("audio_element");

function fadeIn(audio, duration) {
    let volume = 0;
    audio.volume = volume;
    audio.play();
    const step = 0.1 / (duration / 100);
    const fadeInInterval = setInterval(() => {
        if (volume < 1) {
            volume += step;
            audio.volume = Math.min(volume, 1);
        } else {
            clearInterval(fadeInInterval);
        }
    }, 100);
}

function fadeOut(audio, duration) {
    let volume = audio.volume;
    const step = 0.1 / (duration / 100);
    const fadeOutInterval = setInterval(() => {
        if (volume > 0) {
            volume -= step;
            audio.volume = Math.max(volume, 0);
        } else {
            audio.pause();
            clearInterval(fadeOutInterval);
        }
    }, 100);
}

audioElement.addEventListener("mouseover", () => {
    fadeIn(audioElement, 2000);
});

audioElement.addEventListener("mouseout", () => {
    fadeOut(audioElement, 2000);
});
