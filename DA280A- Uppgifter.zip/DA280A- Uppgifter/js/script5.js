const formArticle = document.getElementById("form_article");
const hideButton = document.getElementById("hide-btn");
const showButton = document.getElementById("show-btn");


// Hide the article
hideButton.addEventListener("click", () => {
    formArticle.style.display = "none";
    hideButton.style.display = "none";
    showButton.style.display = "inline";
});

// Show the article
showButton.addEventListener("click", () => {
    formArticle.style.display = "block";
    showButton.style.display = "none";
    hideButton.style.display = "inline";
});

