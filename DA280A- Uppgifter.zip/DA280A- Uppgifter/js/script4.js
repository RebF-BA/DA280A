
const images = ["images/instaBW.png", "images/instaColor.jpeg"];
var currentIndex = 0;

setInterval(() => {
    const imgElement = document.getElementById("insta-img");
    currentIndex = (currentIndex + 1) % images.length;
    imgElement.src = images[currentIndex];
}, 3000);

document.getElementById("insta-img").addEventListener("mouseover", () => {
    document.getElementById("insta-img").src = "images/instaColor.jpeg";
});

document.getElementById("insta-img").addEventListener("mouseout", () => {
    document.getElementById("insta-img").src = "images/instaBW.png";
});