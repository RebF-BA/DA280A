console.log("console this ")

function VarianceCheck(arr) {
    if (arr.length === 0) {
        return null;
    }
    else if (!Array.isArray(arr)) {
        return "Error: Not an array";
    }
    else if (!arr.every(item => typeof item === "number")) {
        return "Error: Array contains non-numeric values.";
    }
    else {
        const mean = arr.reduce((a, b) => a + b, 0) / arr.length;
        const variance = arr.reduce((sum, num) => sum + Math.pow(num - mean, 2), 0) / arr.length;
        return variance;
    }
}


function countDaysBetweenDates(date1, date2) {
    const d1 = new Date(date1);
    const d2 = new Date(date2);
    if (isNaN(d1) || isNaN(d2)) {
        return console.log("Error: Invalid date format, pleese use YYYY-MM-DD");
    }
    const diffInMs = Math.abs(d2 - d1);
    return diffInMs / (1000 * 60 * 60 * 24);
}


function charOccurrences(str, char) {
    if (typeof str !== "string" || typeof char !== "string") {
        return "Error: Inputs must be strings.";
    }
    return str.split(char).length - 1;
}


function validateEmail(email) {
    const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return emailPattern.test(email);
}

